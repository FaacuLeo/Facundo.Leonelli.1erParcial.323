﻿using System;
using Biblioteca;
namespace Biblioteca
{
    public abstract class Consulta
    {
        private DateTime fecha;
        private Paciente paciente;

        //public DateTime Fecha { get { return fecha; } }

        //public Paciente Paciente { get { return paciente; } }

        public Consulta(DateTime fecha, Paciente paciente)
        {
            this.fecha = fecha;
            this.paciente = paciente;
        }
        public DateTime Fecha
        {
            get { return fecha; }
        }

        public Paciente Paciente
        {
            get { return paciente; }
        }

        public override string ToString()
        {
            return $"{Fecha} se ha atendido a {Paciente.NombreCompleto}";
        }




        //public override string ToString()
        //{
        //    return base.ToString();
        //}




    }
}
